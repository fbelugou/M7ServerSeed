﻿using Domain.Entities;

namespace Domain.Exceptions;
public class NotFoundEntityException<T> : Exception where T : Entity
{
    public NotFoundEntityException(int id) : base($"Entity of type {typeof(T).Name} with id {id} was not found.")
    {
    }
}
